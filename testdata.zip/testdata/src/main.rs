use actix_web::{get, post, patch,delete,web::{self, Form}, 
    App, HttpResponse, HttpServer, Responder
};
use serde::{Deserialize, Serialize};
use futures_util::{stream::TryStreamExt};
use mongodb::{bson::doc, 
            options::IndexOptions, Client, Collection, IndexModel, 
            results::DeleteResult};



#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct User {
    email: String,
    Compass: String,
    Company_name: String,

    Company_address: String,
    Company_city:String,

    
}

const DB_COM: &str = "companydatabase";
const COLL_COM: &str = "company";

#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct Update {
    Company_name: String,

    Company_address: String,
    Company_city:String,
}


#[actix_web::main]
async fn main() -> std::io::Result<()> {
    let uri = std::env::var("MONGODB_URI").unwrap_or_else(|_| "mongodb://localhost:27017".into());

    let client = Client::with_uri_str(uri).await.expect("failed to connect");
    create_username_index(&client).await;

    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(client.clone()))
            .service(startdata)
            .service(add_company)
            .service(get_company)
            .service(update_com)
            .service(delete_com)
            .service(get_all_com)
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}

async fn create_username_index(client: &Client) {
    let options = IndexOptions::builder().unique(true).build();
    let model = IndexModel::builder()
        .keys(doc! { "email": 1 })
        .options(options)
        .build();
    client
        .database(DB_COM)
        .collection::<User>(COLL_COM)
        .create_index(model, None)
        .await
        .expect("creating an index should succeed");
}

#[get("/")]
async fn startdata() -> HttpResponse {
    HttpResponse::Ok().body("Connected data")
}

#[post("/add_company")]
async fn add_company(client: web::Data<Client>, valuez: web::Json<User>) -> impl Responder {
    let collection = client.database(DB_COM).collection(COLL_COM);

    let result = collection.insert_one(valuez, None).await;
    match result {
        Ok(_) => HttpResponse::Ok().body("company added"),
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
}

#[get("/get_company/{email}")]
async fn get_company(client: web::Data<Client>, email: web::Path<String>) -> HttpResponse {
    let collection: Collection<User> = client.database(DB_COM).collection(COLL_COM);
    match collection
        .find_one(doc! { "email": &email.to_string() }, None)
        .await
    {
        Ok(Some(user)) => HttpResponse::Ok().json(user),
        Ok(None) => {
            HttpResponse::NotFound().body(format!("No email fount {email}"))
        }
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
}

#[get("/get_all_company")]
async fn get_all_com(client: web::Data<Client>) -> HttpResponse {
    let collection: Collection<User> = client.database(DB_COM).collection(COLL_COM);
    let cursor = collection.find(None, None).await;
    match cursor {
        Ok(cursor) => {
            let users: Vec<User> = cursor.try_collect().await.unwrap();
            println!("print {:?}",users);
            HttpResponse::Ok().json(users)
        }
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
}

#[patch("/update/{email}")]
async fn update_com(client: web::Data<Client>,updt: web::Form<Update>, email: web::Path<String>) -> impl Responder {
    let collection: Collection<User> = client.database(DB_COM).collection(COLL_COM);
    
    let updt_val = doc! { "$set": {
        "Company_name": &updt.Company_name,
        "Company_address": &updt.Company_address,
        "Company_city":&updt.Company_city
        
    }
    };

    match collection.update_one(doc! { "company": &email.to_string()},updt_val, None).await {
        Ok(_) => HttpResponse::Ok().body("comapny updated"),
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
    
    
}

#[delete("/delete_data/{email}")]
async fn delete_com(client: web::Data<Client>, email: web::Path<String>) -> HttpResponse {
    let collection: Collection<User> = client.database(DB_COM).collection(COLL_COM);
    match collection
        .delete_one(doc! { "username": &email.to_string() }, None)
        .await
    {
        
        Ok(_) => HttpResponse::Ok().body("company deleted"),
        Err(_) => HttpResponse::InternalServerError().body("No email found "),
    }
}




